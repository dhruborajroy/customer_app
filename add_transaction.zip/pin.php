<?php
// pin.php
session_start();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $pin = $_POST['pin'] ?? '';
  if ($pin === '0185') {
    $_SESSION['authenticated'] = true;
    header("Location: index.php");
    exit;
  } else {
    $error = "Incorrect PIN. Please try again.";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Enter PIN</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
  <h3>Enter PIN to Access Dashboard</h3>
  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
  <?php endif; ?>
  <form method="post" class="mt-4" style="max-width: 400px;">
    <div class="mb-3">
      <label class="form-label">PIN</label>
      <input type="number" name="pin" class="form-control" required autofocus>
    </div>
    <button type="submit" class="btn btn-primary">Login</button>
  </form>
</div>
</body>
</html>
