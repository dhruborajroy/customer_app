
<?php
// Function to generate WhatsApp link with a URL-encoded message
function generateWhatsAppLink($phone, $message) {
  // URL encode the message to ensure all characters are properly encoded
  $encodedMessage = urlencode($message);
  $whatsappLink = "https://wa.me/$phone?text=$encodedMessage"; // Create WhatsApp link
  return $whatsappLink;
}

// add_transaction.php
include 'db.php';
$customer_id = intval($_GET['id'] ?? 0);
$customer = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM customers WHERE id = $customer_id"));
if (!$customer) {
  echo "Customer not found.";
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $type = mysqli_real_escape_string($conn, $_POST['type']);
  $amount = floatval($_POST['amount']);
  $customer_phone = mysqli_real_escape_string($conn, $_POST['customer_phone']);
  $note = mysqli_real_escape_string($conn, $_POST['note']);
  $date = date("Y-m-d h:i:s");

  // Total Credit
  $credit_result = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(amount) as total_credit FROM transactions WHERE type = 'credit' and customer_id='$customer_id'"));
  $total_credit = $credit_result['total_credit'] ?? 0;

  // Total Debit
  $debit_result = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(amount) as total_debit FROM transactions WHERE type = 'debit'  and customer_id='$customer_id'"));
  $total_debit = $debit_result['total_debit'] ?? 0;
  // Balance
  $previous_balance = $total_credit - $total_debit;


  // Build the SQL query string
  $sql = "INSERT INTO transactions (customer_id, type, amount, description, date) 
          VALUES ($customer_id, '$type', $amount, '$note', '$date')";
  
  // Execute the query
  mysqli_query($conn, $sql);
  
  $customerPhone = "+88".$customer_phone; // Customer's phone number (including country code)

  // Total Credit
  $credit_result = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(amount) as total_credit FROM transactions WHERE type = 'credit' and customer_id='$customer_id'"));
  $total_credit = $credit_result['total_credit'] ?? 0;

  // Total Debit
  $debit_result = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(amount) as total_debit FROM transactions WHERE type = 'debit'  and customer_id='$customer_id'"));
  $total_debit = $debit_result['total_debit'] ?? 0;

  $message = "লেনদেন রেকর্ড\n";
  $message .= "কাস্টমার মোবাইল নং $customer_phone\n";

  // Balance
  $balance = $total_credit - $total_debit;
  if($balance>0){
    if($type=='credit'){
      $msg_type="কেনা";
    }else{
      $msg_type="জমা";
    }
    if($previous_balance<0){
      $message .= "পূর্বের জমা ".abs($previous_balance)."\n";
      $message .= "$msg_type $amount\n";
      $message .= "বর্তমান বাকি ".abs($balance)."\n\n";
    }else{
      $message .= "পূর্বের বাকি $previous_balance\n";
      $message .= "$msg_type $amount\n";
      $message .= "বর্তমান বাকি ".abs($balance)."\n\n";
    }
  }else{
    if($type=='credit'){
      $msg_type="কেনা";
    }else{
      $msg_type="জমা";
    }
    
    if($previous_balance<0){
      $message .= "পূর্বের জমা ".abs($previous_balance)."\n";
      $message .= "$msg_type $amount\n";
      $message .= "বর্তমান জমা ".abs($balance)."\n\n";
    }else{
      $message .= "পূর্বের বাকি $previous_balance\n";
      $message .= "$msg_type $amount\n";
      $message .= "বর্তমান জমা ".abs($balance)."\n\n";
    }
  }
  $message .= "Dhrubo's Printing Services\n";
  $message .= "Barishal Engineering College";

  // echo nl2br($message);
  // // Generate WhatsApp link
  $whatsappLink = generateWhatsAppLink($customerPhone, $message);

  // Redirect
  header("Location: $whatsappLink");
  exit;
  
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Transaction</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Transactions of <?= htmlspecialchars($customer['name']) ?></h3>
    <div>
      <a href="index.php" class="btn btn-success">Home</a>
    </div>
  </div>
  <form method="post" class="mt-4">
    <div class="mb-3">
      <label class="form-label">Transaction Type</label>
      <select name="type" class="form-select" required>
        <option value="credit">বিক্রি করলাম</option>
        <option value="debit">টাকা পেলাম</option>
      </select>
    </div>
    <input type="hidden" name="customer_phone" value="<?= $customer['phone'] ?>">
    <div class="mb-3">
      <label class="form-label">Amount (৳)</label>
      <input type="number" name="amount" step="0.01" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Note</label>
      <input type="text" name="note" class="form-control">
    </div>
    <div class="mb-3">
      <label class="form-label">Date</label>
      <input type="date" name="date" class="form-control" required value="<?= date('Y-m-d') ?>">
    </div>
    <button type="submit" class="btn btn-primary">Add Transaction</button>
    <a href="details.php?id=<?= $customer_id ?>" class="btn btn-secondary">Cancel</a>
  </form>
</div>
</body>
</html>
