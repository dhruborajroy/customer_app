
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Dhrubo's Printing Services</h2>
    <a href="add_customer.php" class="btn btn-success">+ Add Customer</a>
  </div>