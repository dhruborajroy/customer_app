
<?php
// index.php
include 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Customer Balance App</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .badge {
      font-size: 0.9rem;
    }
  </style>
</head>
<body>
<!-- add_customer.php -->
<?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && basename($_SERVER['PHP_SELF']) === 'add_customer.php') {
  include 'db.php';
  $name = mysqli_real_escape_string($conn, $_POST['name']);
  $phone = mysqli_real_escape_string($conn, $_POST['phone']);
  mysqli_query($conn, "INSERT INTO customers (name, phone) VALUES ('$name', '$phone')");
  header("Location: index.php");
  exit;
} ?>

<div class="container py-4">
  <h3>Add New Customer</h3>
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div>
      <a href="index.php" class="btn btn-success">Home</a>
    </div>
  </div>
  <form method="POST" action="">
    <div class="mb-3">
      <label for="name" class="form-label">Name</label>
      <input type="text" name="name" id="name" class="form-control" required>
    </div>
    <div class="mb-3">
      <label for="phone" class="form-label">Phone</label>
      <input type="text" name="phone" id="phone" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary">Add Customer</button>
    <a href="index.php" class="btn btn-secondary">Cancel</a>
  </form>
</div>
